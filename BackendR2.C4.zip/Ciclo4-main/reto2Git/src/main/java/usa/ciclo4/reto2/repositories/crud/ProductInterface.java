/** < - - - - - - - - { G3 } - - - - - - - - > */


package usa.ciclo4.reto2.repositories.crud;


import org.springframework.data.repository.CrudRepository;
import usa.ciclo4.reto2.models.Product;




public interface ProductInterface extends CrudRepository<Product, Integer> {
    
    
    
}


